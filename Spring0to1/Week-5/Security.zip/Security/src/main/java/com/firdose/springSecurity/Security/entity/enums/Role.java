package com.firdose.springSecurity.Security.entity.enums;

public enum Role {

    ADMIN,
    USER,
    CREATOR
}
