package com.firdose.springSecurity.Security.constants;

public class Constants {

    public static final int SESSION_LIMIT = 3;
}
