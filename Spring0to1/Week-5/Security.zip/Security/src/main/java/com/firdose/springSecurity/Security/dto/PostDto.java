package com.firdose.springSecurity.Security.dto;

import lombok.Data;

@Data
public class PostDto {

    private Long Id;
    private String name;
    private String description;
}
